/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Buhle
 */
package com.mycompany.chatapppt1;


import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        
        //allows for the users input for their information
        Scanner input = new Scanner(System.in);
        
        //creating an object for the login class so we cn call its methods
        Login login = new Login();
   
       
// REGISTRATION SECTION
    System.out.println("===USER REGISTRATION===");
    
    System.out.print("Enter a username: ");
    String username = input.nextLine();
    
    System.out.print("Enter a password: ");
    String password = input.nextLine();
    
    System.out.print("Enter your Suth African phone number (+27...): ");
    String phone = input.nextLine();
    
    //Call the registerUser method and store the message it returns
    String response = login.registerUser(username, password, phone);
    
    //Show th registration message
    System.out.println(response);
    
    //LOGIN SECTION
    System.out.println("=== USER LOGIN ===");
    
    System.out.print("Enter a username: ");
     String loginUsername = input.nextLine();
     
     System.out.print("Enter your password: ");
     String loginPassword = input.nextLine();
     
     // Call loginUser to check if details match the stored ones
     boolean loggedIn = login.loginUser(loginUsername, loginPassword);
     
     // Print out the correct login message
     String loginMessage = login.returnLoginStatus(loggedIn);
     System.out.println(loginMessage);
     
    
    
}
}
